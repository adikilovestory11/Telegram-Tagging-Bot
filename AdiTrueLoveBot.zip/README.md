# Adi & True Love Telegram Bot

This bot tags all users one by one in group with funny messages.

## Commands

- `/start` — Show welcome message
- `/tagall` — Start tagging users
- `/stop` — Stop tagging

## Credits

Made with love by Adi @Adi_11250 and True Love
