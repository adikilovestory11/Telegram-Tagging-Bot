from telethon import TelegramClient, events
import asyncio
import random

api_id = 22443811
api_hash = '923a6f2eaaf49c2e0fbb5b7c4701bbc7'
bot_token = '7643526438:AAGg9Ii4PazKu9sqtmoPa9gS8V-_lUG4POc'

client = TelegramClient('bot_session', api_id, api_hash).start(bot_token=bot_token)

funny_messages = [
    "किधर चले सब? पार्टी तो अभी शुरू हुई है!",
    "रुको! सबको mention कर रहा हूँ!",
    "चलो भाई, उठ जाओ! Attendance हो रही है!",
    "अरे वाह, इतने सुंदर लोग एक जगह!",
    "किसी ने चाय मंगवाई क्या?",
    "हाज़िरी लगाओ, नहीं तो मीटिंग कैंसिल!",
    "बोट आ गया है सबको परेशान करने!",
    "तुम सबको tag करके मुझे बहुत मज़ा आता है!",
    "इतने बड़े नाम, क्या बात है!",
    "सबको tag कर दिया, अब लोग घर से बाहर नहीं जा सकेंगे!",
]

is_tagging = {}

@client.on(events.NewMessage(pattern='/start'))
async def on_start(event):
    sender = await event.get_sender()
    name = sender.first_name
    message = (
        f"Hello {name}!

"
        "**मैं एक Group Tagging बोट हूँ.**

"
        "**Commands:**
"
        "`/tagall` - सबको एक-एक करके tag करे
"
        "`/stop` - tagging रोकने के लिए

"
        "Regards,
Adi @Adi_11250 & True Love"
    )
    await event.reply(message)

@client.on(events.NewMessage(pattern='/tagall'))
async def tag_all(event):
    global is_tagging
    if event.is_private:
        await event.reply("यह कमांड सिर्फ group में ही काम करती है।")
        return

    if is_tagging.get(event.chat_id, False):
        await event.reply("Tagging already in progress!")
        return

    is_tagging[event.chat_id] = True
    users = await client.get_participants(event.chat_id)
    for user in users:
        if not is_tagging.get(event.chat_id):
            break
        try:
            if user.bot or user.deleted:
                continue
            msg = random.choice(funny_messages)
            await event.respond(f"{msg} [{user.first_name}](tg://user?id={user.id})", parse_mode='md')
            await asyncio.sleep(2)
        except Exception as e:
            print("Error tagging:", e)
            continue
    is_tagging[event.chat_id] = False
    await event.respond("Done tagging!")

@client.on(events.NewMessage(pattern='/stop'))
async def stop_tagging(event):
    global is_tagging
    is_tagging[event.chat_id] = False
    await event.reply("Tagging process stopped!")

print("Bot is running...")
client.run_until_disconnected()
